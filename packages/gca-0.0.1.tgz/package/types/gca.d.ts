import * as i0 from "@angular/core";
export declare class Gca {
  static ɵfac: i0.ɵɵFactoryDeclaration<Gca, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Gca, "lib-gca", never, {}, {}, never, never, true, never>;
}