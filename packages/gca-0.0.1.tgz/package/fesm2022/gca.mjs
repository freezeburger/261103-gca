import * as i0 from "@angular/core";
import { Component } from "@angular/core";
var Gca = class Gca {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: Gca,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: Gca,
		isStandalone: true,
		selector: "lib-gca",
		ngImport: i0,
		template: ` <p>gca works!</p> `,
		isInline: true,
		styles: [""]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: Gca,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "lib-gca",
			template: ` <p>gca works!</p> `
		}]
	}]
});
export { Gca };

//# sourceMappingURL=gca.mjs.map